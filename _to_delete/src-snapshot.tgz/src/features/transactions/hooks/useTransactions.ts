import { keepPreviousData, useInfiniteQuery, useQuery } from "@tanstack/react-query";

import { transactionsService } from "../services/transaction.service";
import { TRANSACTION_RELATIONS_QUERY_VERSION } from "../constants";
import { useAuth } from "@/providers/AuthProvider";
import type { TransactionFilters, TransactionMovementFilters } from "@/repositories/transactions.repository";

export function useTransactionMovementsInfinite(
  filters: TransactionMovementFilters = {},
  pageSize = 25,
  options?: { enabled?: boolean },
) {
  const { householdId, isLoading } = useAuth();
  return useInfiniteQuery({
    queryKey: ["transaction-movements", householdId, filters, pageSize],
    queryFn: ({ pageParam = 0 }) => transactionsService.getMovements(householdId!, {
      ...filters,
      limit: pageSize,
      offset: pageParam,
    }),
    initialPageParam: 0,
    getNextPageParam: (lastPage, pages) =>
      lastPage.length < pageSize ? undefined : pages.length * pageSize,
    staleTime: 0,
    // Keep the previous filter/sort's pages on screen while the next query
    // key's fetch resolves, instead of dropping to `undefined` and flashing
    // the empty state on every filter change.
    placeholderData: keepPreviousData,
    // Do not keep every page a user has ever scrolled through. Otherwise an
    // infinite query refetches all cached pages when this screen is opened
    // again, which defeats server-side lazy loading.
    gcTime: 0,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
    enabled: (options?.enabled ?? true) && !!householdId && !isLoading,
  });
}

/**
 * Paginated, newest-first ledger for ONE account, with a real running
 * balance after every row -- including split transactions, which
 * useTransactionMovementsInfinite (and the balance_after_transaction it
 * carries) deliberately leaves null. Backs the Accounts screen's "Account
 * History" view -- see list_account_ledger /
 * 20260901000600_account_ledger_running_balance.sql.
 */
export function useAccountLedgerInfinite(
  accountId: string | undefined,
  pageSize = 25,
  options?: { enabled?: boolean },
) {
  const { householdId, isLoading } = useAuth();
  return useInfiniteQuery({
    queryKey: ["account-ledger", householdId, accountId, pageSize],
    queryFn: ({ pageParam = 0 }) => transactionsService.getAccountLedger(householdId!, accountId!, {
      limit: pageSize,
      offset: pageParam,
    }),
    initialPageParam: 0,
    getNextPageParam: (lastPage, pages) =>
      lastPage.length < pageSize ? undefined : pages.length * pageSize,
    staleTime: 0,
    placeholderData: keepPreviousData,
    gcTime: 0,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
    enabled: (options?.enabled ?? true) && !!householdId && !isLoading && !!accountId,
  });
}

/**
 * Aggregates (count, income total, expense total, net) over the FULL
 * filtered movement set -- not just the pages currently loaded by
 * useTransactionMovementsInfinite -- to back a results-summary bar above the
 * Transactions list.
 */
export function useTransactionMovementsSummary(
  filters: TransactionMovementFilters = {},
  options?: { enabled?: boolean },
) {
  const { householdId, isLoading } = useAuth();
  return useQuery({
    queryKey: ["transaction-movements-summary", householdId, filters],
    queryFn: () => transactionsService.getMovementsSummary(householdId!, filters),
    staleTime: 0,
    // Keep the previous summary totals on screen while the next query key's
    // fetch resolves, instead of dropping to `undefined` on every filter
    // change.
    placeholderData: keepPreviousData,
    enabled: (options?.enabled ?? true) && !!householdId && !isLoading,
  });
}

export function useTransactions(
  filters: TransactionFilters = {},
  options?: { enabled?: boolean },
) {
  const { householdId, isLoading } = useAuth();

  return useQuery({
    queryKey: [
      "transactions",
      householdId,
      filters,
      TRANSACTION_RELATIONS_QUERY_VERSION,
    ],
    queryFn: () => transactionsService.getTransactions(householdId!, filters),
    enabled: (options?.enabled ?? true) && !!householdId && !isLoading,
  });
}

/** Loads every transaction in a bounded filter range without PostgREST row truncation. */
export function useAllTransactions(
  filters: TransactionFilters = {},
  options?: { enabled?: boolean },
) {
  const { householdId, isLoading } = useAuth();

  return useQuery({
    queryKey: [
      "transactions",
      "all",
      householdId,
      filters,
      TRANSACTION_RELATIONS_QUERY_VERSION,
    ],
    queryFn: async () => {
      const pageSize = 500;
      const rows = [];

      for (let offset = 0; ; offset += pageSize) {
        const page = await transactionsService.getTransactions(householdId!, {
          ...filters,
          limit: pageSize,
          offset,
        });
        rows.push(...page);
        if (page.length < pageSize) break;
      }

      return rows;
    },
    enabled: (options?.enabled ?? true) && !!householdId && !isLoading,
  });
}

export function useTransactionsInfinite(
  filters: TransactionFilters = {},
  pageSize = 25,
  options?: { enabled?: boolean },
) {
  const { householdId, isLoading } = useAuth();

  return useInfiniteQuery({
    queryKey: [
      "transactions",
      householdId,
      filters,
      pageSize,
      "infinite",
      TRANSACTION_RELATIONS_QUERY_VERSION,
    ],
    queryFn: ({ pageParam = 0 }) =>
      transactionsService.getTransactions(householdId!, {
        ...filters,
        limit: pageSize,
        offset: pageParam,
      }),
    initialPageParam: 0,
    getNextPageParam: (lastPage, pages) =>
      lastPage.length < pageSize ? undefined : pages.length * pageSize,
    // The application-wide stale time must not allow a previously visited
    // filter combination to skip its request when it becomes active again.
    staleTime: 0,
    refetchOnMount: "always",
    enabled: (options?.enabled ?? true) && !!householdId && !isLoading,
  });
}

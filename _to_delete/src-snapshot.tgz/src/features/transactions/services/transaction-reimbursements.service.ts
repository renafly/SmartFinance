import { repositories } from "@/repositories";
import { validateReimbursementDraft } from "@/features/transactions/utils/reimbursements";
import type { AllocationSourceType } from "@/features/transactions/utils/transaction-allocations";

export type CreateReimbursementInput = {
  household_id: string;
  transaction_id: string;
  payer_name: string;
  amount: number;
  note?: string | null;
  created_by: string;
  /**
   * Which of the household's own accounts/pots this reimbursement's money
   * landed in. See 20260901002500_reimbursement_allocations.sql -- nullable
   * at the DB layer so a pre-existing (payer-name-only) row stays valid,
   * but every new row created through the UI always sets these.
   */
  source_type?: AllocationSourceType | null;
  account_id?: string | null;
  pot_id?: string | null;
  /** "YYYY-MM-DD" the repayment arrived; dates the linked income transaction. Defaults to today server-side. */
  received_on?: string | null;
};

export type UpdateReimbursementInput = {
  id: string;
  payer_name?: string;
  amount?: number;
  note?: string | null;
  source_type?: AllocationSourceType | null;
  account_id?: string | null;
  pot_id?: string | null;
  received_on?: string;
};

/**
 * The write path for a transaction's reimbursements. Unlike
 * transactionAllocationsService.replace (which atomically replaces a whole
 * set so it keeps summing to the transaction total), reimbursement rows
 * are independent add/edit/remove operations -- there's no sum invariant
 * to protect -- so this is deliberately simple CRUD. See
 * docs/recurring-end-conditions-reimbursements-bug-fab-plan.md §2.
 */
class TransactionReimbursementsService {
  async getForTransaction(transactionId: string) {
    const { data, error } =
      await repositories.transactionReimbursements.listForTransaction(transactionId);
    if (error) throw error;
    return data ?? [];
  }

  async getEffectiveAmount(transactionId: string) {
    const { data, error } =
      await repositories.transactionReimbursements.getEffectiveAmount(transactionId);
    if (error) throw error;
    return data;
  }

  async listEffectiveAmountsForHousehold(householdId: string) {
    const { data, error } =
      await repositories.transactionReimbursements.listEffectiveAmountsForHousehold(householdId);
    if (error) throw error;
    return data ?? [];
  }

  async getIncomeLink(transactionId: string) {
    const { data, error } =
      await repositories.transactionReimbursements.findIncomeLink(transactionId);
    if (error) throw error;
    return data;
  }

  private toInsert(input: CreateReimbursementInput) {
    const errors = validateReimbursementDraft({
      payerName: input.payer_name,
      amount: input.amount,
      sourceType: input.source_type ?? undefined,
      accountId: input.account_id ?? null,
      potId: input.pot_id ?? null,
    });
    if (errors.length > 0) {
      throw new Error(`Invalid reimbursement: ${errors.join(", ")}`);
    }

    return {
      household_id: input.household_id,
      transaction_id: input.transaction_id,
      payer_name: input.payer_name.trim(),
      amount: input.amount,
      note: input.note?.trim() || null,
      created_by: input.created_by,
      source_type: input.source_type ?? null,
      account_id: input.source_type === "account" ? (input.account_id ?? null) : null,
      pot_id: input.source_type === "pot" ? (input.pot_id ?? null) : null,
      ...(input.received_on ? { received_on: input.received_on } : {}),
    };
  }

  /**
   * Inserting a reimbursement into an account also creates its linked
   * income transaction server-side (sync_reimbursement_income_transaction),
   * so the money lands in that account's balance.
   */
  async createReimbursement(input: CreateReimbursementInput) {
    const { data, error } = await repositories.transactionReimbursements.create(this.toInsert(input));
    if (error) throw error;
    return data;
  }

  /**
   * All-or-nothing: one INSERT statement for every row, so a failure never
   * leaves the expense with only some of its reimbursements (the create
   * wizard used to insert them one by one).
   */
  async createReimbursements(inputs: readonly CreateReimbursementInput[]) {
    if (inputs.length === 0) return [];
    const rows = inputs.map((input) => this.toInsert(input));
    const { data, error } = await repositories.transactionReimbursements.createMany(rows);
    if (error) throw error;
    return data ?? [];
  }

  async updateReimbursement(input: UpdateReimbursementInput) {
    const { id, ...rest } = input;
    if (rest.amount !== undefined && !(rest.amount > 0)) {
      throw new Error("Invalid reimbursement: non_positive_amount");
    }
    if (rest.payer_name !== undefined && !rest.payer_name.trim()) {
      throw new Error("Invalid reimbursement: missing_payer_name");
    }

    if (rest.source_type === "account" && !rest.account_id) {
      throw new Error("Invalid reimbursement: missing_source");
    }
    if (rest.source_type === "pot" && !rest.pot_id) {
      throw new Error("Invalid reimbursement: missing_source");
    }

    const { data, error } = await repositories.transactionReimbursements.update(id, {
      ...rest,
      ...(rest.source_type === "account" ? { pot_id: null } : {}),
      ...(rest.source_type === "pot" ? { account_id: null } : {}),
      payer_name: rest.payer_name?.trim(),
      note: rest.note === undefined ? undefined : rest.note?.trim() || null,
    });
    if (error) throw error;
    return data;
  }

  async deleteReimbursement(id: string) {
    const { error } = await repositories.transactionReimbursements.delete(id);
    if (error) throw error;
  }
}

export const transactionReimbursementsService = new TransactionReimbursementsService();
